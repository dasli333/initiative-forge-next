(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_0902eeac._.js",
  "static/chunks/node_modules_0eeb4986._.js",
  "static/chunks/src_82bb2068._.js",
  "static/chunks/src_app_globals_91e4631d.css"
],
    source: "dynamic"
});
