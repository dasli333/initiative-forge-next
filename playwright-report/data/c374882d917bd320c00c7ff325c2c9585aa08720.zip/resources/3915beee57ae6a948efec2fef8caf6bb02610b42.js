(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/src_2471156b._.js",
  "static/chunks/node_modules_zod_v4_ac66e8b8._.js",
  "static/chunks/node_modules_ad9c93e2._.js"
],
    source: "dynamic"
});
