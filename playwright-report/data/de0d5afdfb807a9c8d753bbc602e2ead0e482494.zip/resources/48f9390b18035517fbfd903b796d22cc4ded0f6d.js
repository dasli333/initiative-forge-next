(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_6ece6ad1._.js",
  "static/chunks/node_modules_5c8bc254._.js",
  "static/chunks/src_0d661ed0._.js",
  "static/chunks/src_app_globals_91e4631d.css"
],
    source: "dynamic"
});
