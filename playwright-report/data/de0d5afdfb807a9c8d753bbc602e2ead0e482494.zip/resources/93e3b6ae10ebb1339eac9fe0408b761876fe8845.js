(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/src_f35c1be4._.js",
  "static/chunks/node_modules_80df410e._.js"
],
    source: "dynamic"
});
