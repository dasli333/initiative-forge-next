(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_@tanstack_query-devtools_build_288b412e._.js",
  "static/chunks/node_modules_@tanstack_1d55c268._.js"
],
    source: "dynamic"
});
