(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/src_abccbd8c._.js",
  "static/chunks/node_modules_3356e185._.js"
],
    source: "dynamic"
});
