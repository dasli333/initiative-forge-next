(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/src_9e2285a9._.js",
  "static/chunks/node_modules_80df410e._.js"
],
    source: "dynamic"
});
